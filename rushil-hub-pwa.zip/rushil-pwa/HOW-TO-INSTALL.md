# 🚀 How to Put R·HUB on Your Android Homescreen
### (Takes about 10 minutes, completely free)

---

## STEP 1 — Create a Free GitHub Account
1. Go to **github.com** on your phone or laptop
2. Sign up for a free account (if you don't have one)

---

## STEP 2 — Create a New Repository
1. Click the **+** button (top right) → "New repository"
2. Name it: `rushil-hub`
3. Set it to **Public**
4. Click **Create repository**

---

## STEP 3 — Upload Your App Files
Upload all 5 files from the ZIP I gave you:
- `index.html`
- `manifest.json`
- `sw.js`
- `icon-192.png`
- `icon-512.png`
- `vercel.json`

To upload: Click **"uploading an existing file"** link on your new repo page → drag all files → click **Commit changes**

---

## STEP 4 — Deploy to Vercel (Free Hosting)
1. Go to **vercel.com**
2. Click **"Sign up"** → choose **"Continue with GitHub"**
3. Click **"New Project"**
4. Find your `rushil-hub` repo → click **Import**
5. Leave all settings as default → click **Deploy**
6. Wait ~30 seconds → Vercel gives you a URL like:
   `https://rushil-hub.vercel.app`

---

## STEP 5 — Add to Android Homescreen 📲
1. Open **Chrome** on your Android phone
2. Go to your Vercel URL (e.g. `https://rushil-hub.vercel.app`)
3. A banner will appear at the bottom: **"Add R·HUB to homescreen"** → tap **Install**
4. If no banner: tap the **3-dot menu** (top right) → **"Add to Home screen"**
5. Tap **Add**

✅ Done! R·HUB icon now appears on your homescreen like a native app.

---

## Notes
- Opens fullscreen, no browser bar — feels like a real app
- Works offline for basic features
- All your notes, tasks, and data are saved on your phone
- YouTube channel scanning works whenever you open the app

---

## Need Help?
Talk to the AI Assistant inside the app — it can guide you through any issues!
